CREATE VIEW `AnsweredQuestionsReport` AS
  SELECT
    `S1`.`AnswerableID`                                    AS `AnswerableID`,
    `S5_2`.`AnsweringGroupID`                              AS `AnsweringGroupID`,
    `S1`.`AnswerableGroupID`                               AS `AnswerableGroupID`,
    `S1`.`QuestionID`                                      AS `QuestionID`,
    `S5`.`AnsweredHTML`                                    AS `AnsweredHTML`,
    `S5_2`.`StartedBy`                                     AS `AnsweredBy`,
    `S1`.`AllowedAttempts`                                 AS `AllowedAttempts`,
    (CASE WHEN isnull(`S5_2`.`StartedBy`)
      THEN 0
     ELSE `S5`.`Attempts` END)                             AS `Attempts`,
    `S1`.`PointsWorth`                                     AS `PointsWorth`,
    `S1`.`CorrectAnswer`                                   AS `CorrectAnswer`,
    `S5`.`ChosenAnswer`                                    AS `ChosenAnswer`,
    (`S1`.`CorrectAnswer` IS NOT NULL)                     AS `HasCorrectAnswer`,
    (CASE WHEN isnull(`S5_2`.`StartedBy`)
      THEN `S1`.`AllowedAttempts`
     ELSE (`S1`.`AllowedAttempts` - `S5`.`Attempts`) END)  AS `RemainingAttempts`,
    (CASE WHEN isnull(`S5_2`.`StartedBy`)
      THEN 1
     ELSE (`S1`.`AllowedAttempts` > `S5`.`Attempts`) END)  AS `Answerable`,
    (CASE WHEN isnull(`S5_2`.`StartedBy`)
      THEN 0
     ELSE (`S1`.`AllowedAttempts` >= `S5`.`Attempts`) END) AS `Locked`,
    (`S5`.`ChosenAnswer` IS NOT NULL)                      AS `HasAnswer`,
    (CASE WHEN (`S5`.`ChosenAnswer` = `S1`.`CorrectAnswer`)
      THEN 1
     ELSE 0 END)                                           AS `IsCorrect`,
    `S4`.`CreatedOn`                                       AS `CreatedOn`,
    `S4`.`CreatedBy`                                       AS `CreatedBy`,
    `S3`.`QuestionType`                                    AS `QuestionType`,
    `S3`.`Question`                                        AS `Question`,
    `S3`.`ExpectedAnswer`                                  AS `ExpectedAnswer`,
    `S3`.`JSONParameters`                                  AS `JSONParameters`,
    `S2`.`UserID`                                          AS `UserID`,
    `S2`.`FirstName`                                       AS `FirstName`,
    `S2`.`LastName`                                        AS `LastName`,
    `S2`.`Email`                                           AS `Email`,
    `S2`.`PhoneNumber`                                     AS `PhoneNumber`,
    `S2`.`UserName`                                        AS `UserName`,
    `S2`.`Password`                                        AS `Password`,
    `S2`.`Role`                                            AS `Role`,
    `S2`.`UHID`                                            AS `UHID`,
    (CASE WHEN ((`S5`.`ChosenAnswer` IS NOT NULL) AND (`S5`.`ChosenAnswer` = `S1`.`CorrectAnswer`))
      THEN `S1`.`PointsWorth`
     ELSE 0 END)                                           AS `PointsEarned`
  FROM (((`hecflore_CELO`.`AnswerableQuestions` `S1` LEFT JOIN `hecflore_CELO`.`Questions` `S3`
      ON ((`S3`.`QuestionID` = `S1`.`QuestionID`))) LEFT JOIN `hecflore_CELO`.`AnswerableQuestionsGroups` `S4`
      ON ((`S4`.`AnswerableGroupID` = `S1`.`AnswerableGroupID`))) JOIN ((`hecflore_CELO`.`Users` `S2`
    JOIN `hecflore_CELO`.`AnsweringQuestionsGroup` `S5_2` ON ((`S2`.`UserID` = `S5_2`.`StartedBy`))) JOIN
    `hecflore_CELO`.`AnsweredQuestions` `S5` ON ((`S5`.`AnsweringGroupID` = `S5_2`.`AnsweringGroupID`))))
  WHERE (`S1`.`AnswerableID` = `S5`.`AnswerableID`)
  UNION ALL SELECT
              `S1`.`AnswerableID`                AS `AnswerableID`,
              `S13`.`AnsweringGroupID`           AS `AnsweringGroupID`,
              `S1`.`AnswerableGroupID`           AS `AnswerableGroupID`,
              `S1`.`QuestionID`                  AS `QuestionID`,
              NULL                               AS `AnsweredHTML`,
              NULL                               AS `AnsweredBy`,
              `S1`.`AllowedAttempts`             AS `AllowedAttempts`,
              0                                  AS `Attempts`,
              `S1`.`PointsWorth`                 AS `PointsWorth`,
              `S1`.`CorrectAnswer`               AS `CorrectAnswer`,
              NULL                               AS `ChosenAnswer`,
              (`S1`.`CorrectAnswer` IS NOT NULL) AS `HasCorrectAnswer`,
              `S1`.`AllowedAttempts`             AS `RemainingAttempts`,
              1                                  AS `Answerable`,
              0                                  AS `Locked`,
              0                                  AS `HasAnswer`,
              0                                  AS `IsCorrect`,
              `S4`.`CreatedOn`                   AS `CreatedOn`,
              `S4`.`CreatedBy`                   AS `CreatedBy`,
              `S3`.`QuestionType`                AS `QuestionType`,
              `S3`.`Question`                    AS `Question`,
              `S3`.`ExpectedAnswer`              AS `ExpectedAnswer`,
              `S3`.`JSONParameters`              AS `JSONParameters`,
              `S2`.`UserID`                      AS `UserID`,
              `S2`.`FirstName`                   AS `FirstName`,
              `S2`.`LastName`                    AS `LastName`,
              `S2`.`Email`                       AS `Email`,
              `S2`.`PhoneNumber`                 AS `PhoneNumber`,
              `S2`.`UserName`                    AS `UserName`,
              `S2`.`Password`                    AS `Password`,
              `S2`.`Role`                        AS `Role`,
              `S2`.`UHID`                        AS `UHID`,
              0                                  AS `PointsEarned`
            FROM ((`hecflore_CELO`.`Users` `S2`
              JOIN `hecflore_CELO`.`UsersAnswersTemp` `S5`) JOIN ((
                (`hecflore_CELO`.`AnswerableQuestions` `S1` LEFT JOIN `hecflore_CELO`.`Questions` `S3`
                    ON ((`S3`.`QuestionID` = `S1`.`QuestionID`))) LEFT JOIN
                `hecflore_CELO`.`AnswerableQuestionsGroups` `S4`
                  ON ((`S4`.`AnswerableGroupID` = `S1`.`AnswerableGroupID`))) JOIN
              `hecflore_CELO`.`AnsweringQuestionsGroup` `S13`
                ON ((`S13`.`AnswerableGroupID` = `S4`.`AnswerableGroupID`))))
            WHERE ((`S1`.`AnswerableID` = `S5`.`AnsweredBy`) AND (NOT (`S2`.`UserID` IN (SELECT DISTINCT `S13`.`StartOn`
                                                                                         FROM (
                                                                                             `hecflore_CELO`.`AnsweredQuestions` `S12`
                                                                                             JOIN
                                                                                             `hecflore_CELO`.`AnsweringQuestionsGroup` `S13`
                                                                                               ON ((
                                                                                               `S13`.`AnsweringGroupID`
                                                                                               =
                                                                                               `S12`.`AnsweringGroupID`)))
                                                                                         WHERE (`S12`.`AnswerableID` =
                                                                                                `S1`.`AnswerableID`)))))