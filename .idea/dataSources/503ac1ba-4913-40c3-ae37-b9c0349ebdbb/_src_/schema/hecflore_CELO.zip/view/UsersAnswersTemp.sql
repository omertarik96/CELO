CREATE VIEW `UsersAnswersTemp` AS
  SELECT
    `S8`.`AnswerableID` AS `AnswerableID`,
    `S9`.`AnsweredHTML` AS `AnsweredHTML`,
    `S3`.`StartedBy`    AS `AnsweredBy`,
    `S9`.`Attempts`     AS `Attempts`,
    `S9`.`ChosenAnswer` AS `ChosenAnswer`,
    `S10`.`UserID`      AS `UserID`,
    `S10`.`FirstName`   AS `FirstName`,
    `S10`.`LastName`    AS `LastName`,
    `S10`.`Email`       AS `Email`,
    `S10`.`PhoneNumber` AS `PhoneNumber`,
    `S10`.`UserName`    AS `UserName`,
    `S10`.`Password`    AS `Password`,
    `S10`.`Role`        AS `Role`,
    `S10`.`UHID`        AS `UHID`
  FROM (((`hecflore_CELO`.`AnswerableQuestions` `S8` LEFT JOIN `hecflore_CELO`.`AnsweredQuestions` `S9`
      ON ((`S9`.`AnswerableID` = `S8`.`AnswerableID`))) JOIN `hecflore_CELO`.`AnsweringQuestionsGroup` `S3`
      ON (((`S3`.`AnswerableGroupID` = `S8`.`AnswerableGroupID`) AND
           (`S3`.`AnsweringGroupID` = `S9`.`AnsweringGroupID`)))) LEFT JOIN `hecflore_CELO`.`Users` `S10`
      ON ((`S3`.`StartedBy` = `S10`.`UserID`)))