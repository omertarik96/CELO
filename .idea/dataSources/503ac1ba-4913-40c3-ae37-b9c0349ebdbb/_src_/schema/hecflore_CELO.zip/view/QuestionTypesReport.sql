CREATE VIEW `QuestionTypesReport` AS
  SELECT
    `S1`.`QuestionTypeID` AS `QuestionTypeID`,
    `S1`.`SrcDirectory`   AS `SrcDirectory`,
    `S1`.`Name`           AS `Name`,
    `S1`.`CreatedBy`      AS `CreatedBy`,
    `S3`.`UserID`         AS `UserID`,
    `S3`.`FirstName`      AS `FirstName`,
    `S3`.`LastName`       AS `LastName`,
    `S3`.`Email`          AS `Email`,
    `S3`.`PhoneNumber`    AS `PhoneNumber`,
    `S3`.`UserName`       AS `UserName`,
    `S3`.`Password`       AS `Password`,
    `S3`.`Role`           AS `Role`,
    `S3`.`UHID`           AS `UHID`
  FROM (`hecflore_CELO`.`QuestionTypes` `S1` LEFT JOIN `hecflore_CELO`.`Users` `S3`
      ON ((`S3`.`UserID` = `S1`.`CreatedBy`)))