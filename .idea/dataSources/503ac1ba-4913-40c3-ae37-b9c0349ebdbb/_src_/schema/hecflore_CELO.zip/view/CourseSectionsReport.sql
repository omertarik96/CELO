CREATE VIEW `CourseSectionsReport` AS
  SELECT
    `S1`.`CourseUniqueID`       AS `CourseUniqueID`,
    `S1`.`CourseName`           AS `CourseName`,
    `S1`.`CourseCategory`       AS `CourseCategory`,
    `S1`.`Setup`                AS `Setup`,
    `S1`.`CourseID`             AS `CourseID`,
    `S1`.`Description`          AS `Description`,
    `S1`.`CourseStatus`         AS `CourseStatus`,
    `S2`.`SectionID`            AS `SectionID`,
    `S2`.`SectionNumber`        AS `SectionNumber`,
    `S2`.`StartDate`            AS `StartDate`,
    `S2`.`EndDate`              AS `EndDate`,
    `S2`.`Location`             AS `Location`,
    `S2`.`TextBookInformation`  AS `TextBookInformation`,
    `S2`.`MainCourseContentID`  AS `MainCourseContentID`,
    `S2`.`CreatedBy`            AS `CreatedBy`,
    `S3`.`AssignedBy`           AS `AssignedBy`,
    (CASE WHEN isnull(`S4`.`UserID`)
      THEN `S2`.`CreatedBy`
     ELSE `S4`.`UserID` END)    AS `UserID`,
    `S4`.`FirstName`            AS `FirstName`,
    `S4`.`LastName`             AS `LastName`,
    `S4`.`Email`                AS `Email`,
    `S4`.`PhoneNumber`          AS `PhoneNumber`,
    `S4`.`UserName`             AS `UserName`,
    `S4`.`Password`             AS `Password`,
    `S4`.`Role`                 AS `Role`,
    `S3`.`UHID`                 AS `UHID`,
    (`S4`.`UserID` IS NOT NULL) AS `isActive`
  FROM (((`hecflore_CELO`.`Courses` `S1` LEFT JOIN `hecflore_CELO`.`Sections` `S2`
      ON ((`S1`.`CourseUniqueID` = `S2`.`CourseUniqueID`))) LEFT JOIN `hecflore_CELO`.`SectionUsers` `S3`
      ON ((`S2`.`SectionID` = `S3`.`SectionID`))) LEFT JOIN `hecflore_CELO`.`Users` `S4`
      ON (((isnull(`S3`.`UserID`) AND (`S3`.`UHID` = `S4`.`UHID`)) OR
           ((`S3`.`UserID` IS NOT NULL) AND (`S3`.`UserID` = `S4`.`UserID`)))))