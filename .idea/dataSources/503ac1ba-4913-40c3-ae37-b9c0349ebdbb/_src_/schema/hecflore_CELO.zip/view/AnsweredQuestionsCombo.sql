CREATE VIEW `AnsweredQuestionsCombo` AS
  SELECT
    `S1`.`AnswerableID`                                    AS `AnswerableID`,
    `S1`.`AnswerableGroupID`                               AS `AnswerableGroupID`,
    `S1`.`QuestionID`                                      AS `QuestionID`,
    `S5`.`AnsweredHTML`                                    AS `AnsweredHTML`,
    `S6`.`StartedBy`                                       AS `AnsweredBy`,
    `S1`.`AllowedAttempts`                                 AS `AllowedAttempts`,
    (CASE WHEN isnull(`S6`.`StartedBy`)
      THEN 0
     ELSE `S5`.`Attempts` END)                             AS `Attempts`,
    `S1`.`PointsWorth`                                     AS `PointsWorth`,
    `S1`.`CorrectAnswer`                                   AS `CorrectAnswer`,
    `S5`.`ChosenAnswer`                                    AS `ChosenAnswer`,
    (`S1`.`CorrectAnswer` IS NOT NULL)                     AS `HasCorrectAnswer`,
    (CASE WHEN isnull(`S6`.`StartedBy`)
      THEN `S1`.`AllowedAttempts`
     ELSE (`S1`.`AllowedAttempts` - `S5`.`Attempts`) END)  AS `RemainingAttempts`,
    (CASE WHEN isnull(`S6`.`StartedBy`)
      THEN 1
     ELSE (`S1`.`AllowedAttempts` > `S5`.`Attempts`) END)  AS `Answerable`,
    (CASE WHEN isnull(`S6`.`StartedBy`)
      THEN 0
     ELSE (`S1`.`AllowedAttempts` >= `S5`.`Attempts`) END) AS `Locked`,
    (`S5`.`ChosenAnswer` IS NOT NULL)                      AS `HasAnswer`,
    (CASE WHEN (`S5`.`ChosenAnswer` = `S1`.`CorrectAnswer`)
      THEN 1
     ELSE 0 END)                                           AS `IsCorrect`
  FROM ((`hecflore_CELO`.`AnswerableQuestions` `S1` LEFT JOIN `hecflore_CELO`.`AnsweredQuestions` `S5`
      ON ((`S5`.`AnswerableID` = `S1`.`AnswerableID`))) LEFT JOIN `hecflore_CELO`.`AnsweringQuestionsGroup` `S6`
      ON ((`S6`.`AnsweringGroupID` = `S5`.`AnsweringGroupID`)))