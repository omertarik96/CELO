CREATE VIEW `GradeProgress_CourseContentTree` AS
  SELECT
    `S1`.`ContentID`                                                          AS `ContentID`,
    `S1`.`ChildContentID`                                                     AS `ChildContentID`,
    `S4`.`Name`                                                               AS `Name`,
    `S4`.`Type`                                                               AS `Type`,
    `S4`.`Depth`                                                              AS `Depth`,
    `S7`.`UserID`                                                             AS `UserID`,
    (CASE WHEN isnull(`S3`.`PointsEarned`)
      THEN 0
     ELSE ((sum(`S3`.`PointsEarned`) / sum(`S3`.`PointsWorth`)) * 100.0) END) AS `Grade`
  FROM (((`hecflore_CELO`.`CourseContentBreadcrumbs` `S1` LEFT JOIN `hecflore_CELO`.`CourseContent` `S4`
      ON ((`S4`.`ContentID` = `S1`.`ChildContentID`))) LEFT JOIN `hecflore_CELO`.`AnswerableQuestionsGroups` `S2`
      ON ((`S2`.`CourseContentID` = `S1`.`ChildContentID`))) LEFT JOIN `hecflore_CELO`.`AnsweredQuestionsReport` `S3`
      ON ((`S3`.`AnswerableGroupID` = `S2`.`AnswerableGroupID`))) JOIN `hecflore_CELO`.`Users` `S7`
  WHERE (`S7`.`UserID` = `S3`.`UserID`)
  GROUP BY `S1`.`ContentID`, `S1`.`ChildContentID`, `S1`.`Name`, `S1`.`Type`, `S1`.`Depth`, `S7`.`UserID`