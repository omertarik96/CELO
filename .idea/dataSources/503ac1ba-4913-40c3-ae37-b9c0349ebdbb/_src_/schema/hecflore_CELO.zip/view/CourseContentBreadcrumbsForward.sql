CREATE VIEW `CourseContentBreadcrumbsForward` AS
  SELECT
    `S2`.`ContentID`      AS `ContentID`,
    `S1`.`ParentFolderID` AS `PreviousContentID`,
    `S1`.`ContentID`      AS `CurrentContentID`,
    `S2`.`ChildContentID` AS `ChildContentID`,
    `S1`.`SectionID`      AS `SectionID`,
    `S1`.`Name`           AS `Name`,
    `S1`.`URL`            AS `URL`,
    `S1`.`Description`    AS `Description`,
    `S1`.`ParentFolderID` AS `ParentFolderID`,
    `S1`.`RootContentID`  AS `RootContentID`,
    `S1`.`Depth`          AS `Depth`,
    `S1`.`Type`           AS `Type`,
    `S1`.`Properties`     AS `Properties`,
    `S1`.`Gradable`       AS `Gradable`,
    `S1`.`CreatedBy`      AS `CreatedBy`,
    `S1`.`RolesVisible`   AS `RolesVisible`
  FROM (`hecflore_CELO`.`CourseContentChildren` `S2`
    JOIN `hecflore_CELO`.`CourseContent` `S1` ON ((`S1`.`ContentID` = `S2`.`ChildContentID`)))