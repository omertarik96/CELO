CREATE VIEW `QuestionsReport` AS
  SELECT
    `S1`.`QuestionID`      AS `QuestionID`,
    `S1`.`QuestionType`    AS `QuestionType`,
    `S1`.`Question`        AS `Question`,
    `S1`.`ExpectedAnswer`  AS `ExpectedAnswer`,
    `S1`.`CreatedBy`       AS `CreatedBy`,
    `S1`.`JSONParameters`  AS `JSONParameters`,
    `S1`.`QuestionsPoolID` AS `QuestionsPoolID`,
    `S3`.`FirstName`       AS `FirstName`,
    `S3`.`LastName`        AS `LastName`,
    `S3`.`Email`           AS `Email`,
    `S3`.`PhoneNumber`     AS `PhoneNumber`
  FROM (`hecflore_CELO`.`Questions` `S1` LEFT JOIN `hecflore_CELO`.`Users` `S3` ON ((`S3`.`UserID` = `S1`.`CreatedBy`)))