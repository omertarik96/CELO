CREATE VIEW `RunningAssessmentsReport` AS
  SELECT
    `S1`.`AnsweredID`                                                                                              AS `AnsweredID`,
    `S1`.`AssessmentID`                                                                                            AS `AssessmentID`,
    `S1`.`StartTime`                                                                                               AS `StartTime`,
    `S1`.`EndTime`                                                                                                 AS `EndTime`,
    `S1`.`TotalPoints`                                                                                             AS `TotalPoints`,
    sum(
        `S4`.`PointsEarned`)                                                                                       AS `EarnedPoints`,
    count(
        `S6`.`AnswerableID`)                                                                                       AS `Answered`,
    count(
        `S4`.`AnswerableID`)                                                                                       AS `TotalQuestions`,
    ((sum(`S4`.`PointsEarned`) / `S1`.`TotalPoints`) *
     100.0)                                                                                                        AS `Grade`,
    (((sum(`S4`.`PointsEarned`) / `S1`.`TotalPoints`) / (sum((CASE WHEN (`S4`.`Attempts` = 0)
      THEN 1
                                                              ELSE 0 END)) / count(`S4`.`AnswerableID`))) *
     100.0)                                                                                                        AS `RelativeGrade`,
    ((sum((CASE WHEN (`S4`.`Attempts` = 0)
      THEN 1
           ELSE 0 END)) / count(`S6`.`AnswerableID`)) *
     100.0)                                                                                                        AS `Finished`,
    `S1`.`AnsweringBy`                                                                                             AS `AnsweringBy`,
    `S1`.`GradedBy`                                                                                                AS `GradedBy`,
    `S1`.`AnsweringGroupID`                                                                                        AS `AnsweringGroupID`,
    `S2`.`Name`                                                                                                    AS `Name`,
    `S2`.`URL`                                                                                                     AS `URL`,
    `S2`.`Description`                                                                                             AS `Description`,
    `S2`.`Type`                                                                                                    AS `Type`,
    `S2`.`Properties`                                                                                              AS `Properties`,
    `S2`.`AssociatedCourseContentID`                                                                               AS `AssociatedCourseContentID`,
    `S2`.`Timelimit`                                                                                               AS `Timelimit`
  FROM (((((`hecflore_CELO`.`RunningAssessments` `S1`
    JOIN `hecflore_CELO`.`Assessments` `S2` ON ((`S2`.`AssessmentID` = `S1`.`AssessmentID`))) JOIN
    `hecflore_CELO`.`AnsweringQuestionsGroup` `S3` ON ((`S3`.`AnsweringGroupID` = `S1`.`AnsweringGroupID`))) LEFT JOIN
    `hecflore_CELO`.`AnsweredQuestionsReport` `S4` ON (((`S4`.`AnswerableGroupID` = `S3`.`AnswerableGroupID`) AND
                                                        (`S1`.`AnsweringBy` = `S4`.`AnsweredBy`)))) LEFT JOIN
    `hecflore_CELO`.`AnswerableQuestions` `S5` ON (((`S5`.`AnswerableGroupID` = `S3`.`AnswerableGroupID`) AND
                                                    (`S4`.`AnswerableID` = `S5`.`AnswerableID`)))) LEFT JOIN
    `hecflore_CELO`.`AnsweredQuestions` `S6` ON ((`S6`.`AnsweringGroupID` = `S1`.`AnsweringGroupID`)))
  GROUP BY `S1`.`AnsweredID`, `S1`.`AssessmentID`, `S1`.`StartTime`, `S1`.`EndTime`, `S1`.`TotalPoints`,
    `S1`.`EarnedPoints`, `S1`.`AnsweringBy`, `S1`.`GradedBy`, `S1`.`AnsweringGroupID`, `S2`.`Name`, `S2`.`URL`,
    `S2`.`Description`, `S2`.`Type`, `S2`.`Properties`, `S2`.`AssociatedCourseContentID`, `S2`.`Timelimit`