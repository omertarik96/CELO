CREATE PROCEDURE `SaveAsTemplate`(`_ContentID` BIGINT(20), `_SectionID` BIGINT(20), `_NameOfTemplate` VARCHAR(200),
                                  `_Notes`     TEXT)
  BEGIN
    INSERT INTO CourseContentTemplates
           (ContentID, Name, URL, Description, ParentFolderID, RootContentID, Depth, Type, Properties, Gradable, CreatedBy, RolesVisible, TemplateName, TemplateNotes)
    SELECT ContentID, Name, URL, Description, ParentFolderID, RootContentID, Depth, Type, Properties, Gradable, CreatedBy, RolesVisible, _NameOfTemplate AS TemplateName ,_Notes AS TemplateNotes   FROM CourseContent
      WHERE SectionID=_SectionID;

  END