CREATE TRIGGER `CourseContentNumberTracker`
BEFORE INSERT ON `CourseContent`
FOR EACH ROW
  BEGIN
      if new.CourseContentNumber IS NULL THEN
        SET new.RootContentID=0;
        SET new.CourseContentNumber=0;
        if new.ParentFolderID is NOT NULL THEN
          SET new.CourseContentNumber=(SELECT (MAX(S1.CourseContentNumber)+1) FROM CourseContent AS S1 WHERE S1.RootContentID=new.RootContentID);
        ELSE
          SET new.RootContentID=0;
        END IF;

      END IF;

    END