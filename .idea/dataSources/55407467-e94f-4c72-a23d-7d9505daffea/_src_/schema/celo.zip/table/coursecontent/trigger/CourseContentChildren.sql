CREATE TRIGGER `CourseContentChildren`
AFTER INSERT ON `coursecontent`
FOR EACH ROW
  BEGIN
    DECLARE ParentID BIGINT;
    DECLARE Depth INTEGER;

    /***********************************************************************/
    /* Get the Parent Id of this course                                    */
    /***********************************************************************/
    SET ParentID=new.ParentFolderID;
    SET Depth=new.Depth;

    /***********************************************************************/
    /* Found it so now we will add it to all parents                       */
    /***********************************************************************/
    IF ParentID IS NOT NULL THEN

      INSERT INTO CourseContentChildren (ContentID, ChildContentID, Depth)
        SELECT S1.ContentID,(new.ContentID) AS ChildContentID,(new.Depth-S1.Depth) AS Depth FROM CourseContentChildren AS S1
          WHERE (S1.ChildContentID = new.ParentFolderID );
      INSERT INTO CourseContentChildren (ContentID, ChildContentID, Depth) VALUES
        (new.ParentFolderID,new.ContentID,new.Depth);



    END IF;
  END