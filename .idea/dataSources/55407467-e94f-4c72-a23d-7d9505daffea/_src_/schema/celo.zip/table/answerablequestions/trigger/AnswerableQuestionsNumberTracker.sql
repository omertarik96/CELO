CREATE TRIGGER `AnswerableQuestionsNumberTracker`
BEFORE INSERT ON `answerablequestions`
FOR EACH ROW
  BEGIN
    if new.AnswerableID IS NULL THEN

      SET new.AnswerableID=NULL; #(SELECT (MAX(S1.AnswerableID)+1) FROM AnswerableQuestions AS S1 WHERE S1.AnswerableGroupID=new.AnswerableGroupID);

    END IF;

  END