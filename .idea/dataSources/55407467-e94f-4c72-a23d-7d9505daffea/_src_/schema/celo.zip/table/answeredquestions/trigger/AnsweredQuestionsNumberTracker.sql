CREATE TRIGGER `AnsweredQuestionsNumberTracker`
BEFORE INSERT ON `answeredquestions`
FOR EACH ROW
  BEGIN
    if new.AnswerableID IS NULL THEN

        SET new.AnswerableID=(SELECT (MAX(S1.AnswerableID)+1) FROM AnsweredQuestions AS S1 WHERE S1.AnsweringGroupID=new.AnsweringGroupID);

    END IF;

  END