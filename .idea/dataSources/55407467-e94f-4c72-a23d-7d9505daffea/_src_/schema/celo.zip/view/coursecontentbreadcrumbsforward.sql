CREATE VIEW `coursecontentbreadcrumbsforward` AS
  SELECT
    `s2`.`ContentID`      AS `ContentID`,
    `s1`.`ParentFolderID` AS `PreviousContentID`,
    `s1`.`ContentID`      AS `CurrentContentID`,
    `s2`.`ChildContentID` AS `ChildContentID`,
    `s1`.`SectionID`      AS `SectionID`,
    `s1`.`Name`           AS `Name`,
    `s1`.`URL`            AS `URL`,
    `s1`.`Description`    AS `Description`,
    `s1`.`ParentFolderID` AS `ParentFolderID`,
    `s1`.`RootContentID`  AS `RootContentID`,
    `s1`.`Depth`          AS `Depth`,
    `s1`.`Type`           AS `Type`,
    `s1`.`Properties`     AS `Properties`,
    `s1`.`Gradable`       AS `Gradable`,
    `s1`.`CreatedBy`      AS `CreatedBy`,
    `s1`.`RolesVisible`   AS `RolesVisible`
  FROM (`celo`.`coursecontentchildren` `s2`
    JOIN `celo`.`coursecontent` `s1` ON ((`s1`.`ContentID` = `s2`.`ChildContentID`)))