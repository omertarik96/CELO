CREATE VIEW `runningassessmentsreport` AS
  SELECT
    `s1`.`AnsweredID`                AS `AnsweredID`,
    `s1`.`AssessmentID`              AS `AssessmentID`,
    `s1`.`StartTime`                 AS `StartTime`,
    `s1`.`EndTime`                   AS `EndTime`,
    `s1`.`TotalPoints`               AS `TotalPoints`,
    `s1`.`EarnedPoints`              AS `EarnedPoints`,
    `s1`.`AnsweringBy`               AS `AnsweringBy`,
    `s1`.`GradedBy`                  AS `GradedBy`,
    `s1`.`AnsweredGroupID`           AS `AnsweredGroupID`,
    `s2`.`Name`                      AS `Name`,
    `s2`.`URL`                       AS `URL`,
    `s2`.`Description`               AS `Description`,
    `s2`.`Type`                      AS `Type`,
    `s2`.`Properties`                AS `Properties`,
    `s2`.`AssociatedCourseContentID` AS `AssociatedCourseContentID`,
    `s2`.`Timelimit`                 AS `Timelimit`
  FROM (`celo`.`runningassessments` `s1`
    JOIN `celo`.`assessments` `s2` ON ((`s2`.`AssessmentID` = `s1`.`AssessmentID`)))