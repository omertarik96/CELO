CREATE VIEW `questionsreport` AS
  SELECT
    `s1`.`QuestionID`      AS `QuestionID`,
    `s1`.`QuestionType`    AS `QuestionType`,
    `s1`.`Question`        AS `Question`,
    `s1`.`ExpectedAnswer`  AS `ExpectedAnswer`,
    `s1`.`CreatedBy`       AS `CreatedBy`,
    `s1`.`JSONParameters`  AS `JSONParameters`,
    `s1`.`QuestionsPoolID` AS `QuestionsPoolID`,
    `s3`.`FirstName`       AS `FirstName`,
    `s3`.`LastName`        AS `LastName`,
    `s3`.`Email`           AS `Email`,
    `s3`.`PhoneNumber`     AS `PhoneNumber`
  FROM (`celo`.`questions` `s1` LEFT JOIN `celo`.`users` `s3` ON ((`s3`.`UserID` = `s1`.`CreatedBy`)))