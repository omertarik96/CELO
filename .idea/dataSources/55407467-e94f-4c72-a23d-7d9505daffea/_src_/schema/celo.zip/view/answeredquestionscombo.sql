CREATE VIEW `answeredquestionscombo` AS
  SELECT
    `s1`.`AnswerableID`                                    AS `AnswerableID`,
    `s1`.`AnswerableGroupID`                               AS `AnswerableGroupID`,
    `s1`.`QuestionID`                                      AS `QuestionID`,
    `s5`.`AnsweredHTML`                                    AS `AnsweredHTML`,
    `s6`.`StartedBy`                                       AS `AnsweredBy`,
    `s1`.`AllowedAttempts`                                 AS `AllowedAttempts`,
    (CASE WHEN isnull(`s6`.`StartedBy`)
      THEN 0
     ELSE `s5`.`Attempts` END)                             AS `Attempts`,
    `s1`.`PointsWorth`                                     AS `PointsWorth`,
    `s1`.`CorrectAnswer`                                   AS `CorrectAnswer`,
    `s5`.`ChosenAnswer`                                    AS `ChosenAnswer`,
    (`s1`.`CorrectAnswer` IS NOT NULL)                     AS `HasCorrectAnswer`,
    (CASE WHEN isnull(`s6`.`StartedBy`)
      THEN `s1`.`AllowedAttempts`
     ELSE (`s1`.`AllowedAttempts` - `s5`.`Attempts`) END)  AS `RemainingAttempts`,
    (CASE WHEN isnull(`s6`.`StartedBy`)
      THEN 1
     ELSE (`s1`.`AllowedAttempts` > `s5`.`Attempts`) END)  AS `Answerable`,
    (CASE WHEN isnull(`s6`.`StartedBy`)
      THEN 0
     ELSE (`s1`.`AllowedAttempts` >= `s5`.`Attempts`) END) AS `Locked`,
    (`s5`.`ChosenAnswer` IS NOT NULL)                      AS `HasAnswer`,
    (CASE WHEN (`s5`.`ChosenAnswer` = `s1`.`CorrectAnswer`)
      THEN 1
     ELSE 0 END)                                           AS `IsCorrect`
  FROM ((`celo`.`answerablequestions` `s1` LEFT JOIN `celo`.`answeredquestions` `s5`
      ON ((`s5`.`AnswerableID` = `s1`.`AnswerableID`))) LEFT JOIN `celo`.`answeringquestionsgroup` `s6`
      ON ((`s6`.`AnsweringGroupID` = `s5`.`AnsweringGroupID`)))