CREATE VIEW `coursesectionsreport` AS
  SELECT
    `s1`.`CourseUniqueID`      AS `CourseUniqueID`,
    `s1`.`CourseName`          AS `CourseName`,
    `s1`.`CourseCategory`      AS `CourseCategory`,
    `s1`.`Setup`               AS `Setup`,
    `s1`.`CourseID`            AS `CourseID`,
    `s1`.`Description`         AS `Description`,
    `s1`.`CourseStatus`        AS `CourseStatus`,
    `s2`.`SectionID`           AS `SectionID`,
    `s2`.`SectionNumber`       AS `SectionNumber`,
    `s2`.`StartDate`           AS `StartDate`,
    `s2`.`EndDate`             AS `EndDate`,
    `s2`.`Location`            AS `Location`,
    `s2`.`TextBookInformation` AS `TextBookInformation`,
    `s2`.`CreatedBy`           AS `CreatedBy`,
    `s2`.`MainCourseContentID` AS `MainCourseContentID`
  FROM (`celo`.`courses` `s1` LEFT JOIN `celo`.`sections` `s2` ON ((`s1`.`CourseUniqueID` = `s2`.`CourseUniqueID`)))