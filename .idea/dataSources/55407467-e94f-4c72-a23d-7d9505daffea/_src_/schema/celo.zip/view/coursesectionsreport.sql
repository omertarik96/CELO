CREATE VIEW `coursesectionsreport` AS
  SELECT
    `s1`.`CourseUniqueID`       AS `CourseUniqueID`,
    `s1`.`CourseName`           AS `CourseName`,
    `s1`.`CourseCategory`       AS `CourseCategory`,
    `s1`.`Setup`                AS `Setup`,
    `s1`.`CourseID`             AS `CourseID`,
    `s1`.`Description`          AS `Description`,
    `s1`.`CourseStatus`         AS `CourseStatus`,
    `s2`.`SectionID`            AS `SectionID`,
    `s2`.`SectionNumber`        AS `SectionNumber`,
    `s2`.`StartDate`            AS `StartDate`,
    `s2`.`EndDate`              AS `EndDate`,
    `s2`.`Location`             AS `Location`,
    `s2`.`TextBookInformation`  AS `TextBookInformation`,
    `s2`.`MainCourseContentID`  AS `MainCourseContentID`,
    `s2`.`CreatedBy`            AS `CreatedBy`,
    `s3`.`AssignedBy`           AS `AssignedBy`,
    (CASE WHEN isnull(`s4`.`UserID`)
      THEN `s2`.`CreatedBy`
     ELSE `s4`.`UserID` END)    AS `UserID`,
    `s4`.`FirstName`            AS `FirstName`,
    `s4`.`LastName`             AS `LastName`,
    `s4`.`Email`                AS `Email`,
    `s4`.`PhoneNumber`          AS `PhoneNumber`,
    `s4`.`UserName`             AS `UserName`,
    `s4`.`Password`             AS `Password`,
    `s4`.`Role`                 AS `Role`,
    `s3`.`UHID`                 AS `UHID`,
    (`s4`.`UserID` IS NOT NULL) AS `isActive`
  FROM (((`celo`.`courses` `s1` LEFT JOIN `celo`.`sections` `s2`
      ON ((`s1`.`CourseUniqueID` = `s2`.`CourseUniqueID`))) LEFT JOIN `celo`.`sectionusers` `s3`
      ON ((`s2`.`SectionID` = `s3`.`SectionID`))) LEFT JOIN `celo`.`users` `s4`
      ON (((isnull(`s3`.`UserID`) AND (`s3`.`UHID` = `s4`.`UHID`)) OR
           ((`s3`.`UserID` IS NOT NULL) AND (`s3`.`UserID` = `s4`.`UserID`)))))