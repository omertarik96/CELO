CREATE VIEW `usersanswerstemp` AS
  SELECT
    `s8`.`AnswerableID` AS `AnswerableID`,
    `s9`.`AnsweredHTML` AS `AnsweredHTML`,
    `s3`.`StartedBy`    AS `AnsweredBy`,
    `s9`.`Attempts`     AS `Attempts`,
    `s9`.`ChosenAnswer` AS `ChosenAnswer`,
    `s10`.`UserID`      AS `UserID`,
    `s10`.`FirstName`   AS `FirstName`,
    `s10`.`LastName`    AS `LastName`,
    `s10`.`Email`       AS `Email`,
    `s10`.`PhoneNumber` AS `PhoneNumber`,
    `s10`.`UserName`    AS `UserName`,
    `s10`.`Password`    AS `Password`,
    `s10`.`Role`        AS `Role`,
    `s10`.`UHID`        AS `UHID`
  FROM (((`celo`.`answerablequestions` `s8` LEFT JOIN `celo`.`answeredquestions` `s9`
      ON ((`s9`.`AnswerableID` = `s8`.`AnswerableID`))) JOIN `celo`.`answeringquestionsgroup` `s3`
      ON (((`s3`.`AnswerableGroupID` = `s8`.`AnswerableGroupID`) AND
           (`s3`.`AnsweringGroupID` = `s9`.`AnsweringGroupID`)))) LEFT JOIN `celo`.`users` `s10`
      ON ((`s3`.`StartedBy` = `s10`.`UserID`)))