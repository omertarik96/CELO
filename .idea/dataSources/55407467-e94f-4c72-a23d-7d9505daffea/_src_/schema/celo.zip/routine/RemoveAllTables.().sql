CREATE PROCEDURE `RemoveAllTables`()
  BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE TableName VARCHAR(100);
    DECLARE sqlString VARCHAR(200);
    DECLARE tablesCursor CURSOR FOR SELECT table_name FROM information_schema.tables where table_schema='CELO';
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN tablesCursor;

    read_loop: LOOP
      FETCH tablesCursor INTO TableName;
      IF done THEN
        LEAVE read_loop;
      END IF;
      SET @sqlString = CONCAT('DROP TABLE ',TableName);
      PREPARE stmt FROM @sqlString;
      EXECUTE stmt;

    END LOOP;

    CLOSE tablesCursor;

  END