CREATE PROCEDURE `RemoveAllForeignKeys`()
  BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE TableName VARCHAR(100);
    DECLARE sqlString VARCHAR(200);
    DECLARE ConstraintName VARCHAR(100);
    DECLARE foreignKeysCursor CURSOR FOR select constraint_name, table_name from information_schema.table_constraints where constraint_schema = 'CELO' AND constraint_type = 'FOREIGN KEY';
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN foreignKeysCursor;

      read_loop: LOOP
        FETCH foreignKeysCursor INTO ConstraintName, TableName;
        IF done THEN
          LEAVE read_loop;
        END IF;
        SET @sqlString = CONCAT('ALTER TABLE ',TableName,' DROP FOREIGN KEY ',ConstraintName);
        PREPARE stmt FROM @sqlString;
        EXECUTE stmt;

      END LOOP;

    CLOSE foreignKeysCursor;

  END