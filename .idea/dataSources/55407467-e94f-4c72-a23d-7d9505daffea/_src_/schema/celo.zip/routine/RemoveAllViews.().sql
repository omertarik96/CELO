CREATE PROCEDURE `RemoveAllViews`()
  BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE ViewName VARCHAR(100);
    DECLARE sqlString VARCHAR(200);
    DECLARE viewsCursor CURSOR FOR SELECT TABLE_NAME FROM information_schema.`TABLES` WHERE TABLE_TYPE LIKE 'VIEW' AND TABLE_SCHEMA LIKE 'CELO';
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN viewsCursor;

    read_loop: LOOP
      FETCH viewsCursor INTO ViewName;
      IF done THEN
        LEAVE read_loop;
      END IF;
      SET @sqlString = CONCAT('DROP VIEW ',ViewName);
      PREPARE stmt FROM @sqlString;
      EXECUTE stmt;

    END LOOP;

    CLOSE viewsCursor;

  END